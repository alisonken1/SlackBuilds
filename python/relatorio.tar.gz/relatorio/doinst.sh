#
# Empty doinst.sh since this does not have any options
#
